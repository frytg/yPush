/*

	yPush

	GIT			https://github.com/frytg/yPush

	DEBUG		-> README.md

	AUTHOR		Daniel Freytag
				daniel@frytg.com
				https://twitter.com/FRYTG

	UPDATED		October 2018

*/

/* ============================================ INIT ============================================ */
/* ============================================ INIT ============================================ */
/* ============================================ INIT ============================================ */


const config = {};

config.telegram = {};
config.telegram.token			= "567531143:AAFaP1tLJ__vkSQ0d8kaImsGp44OXcweM0c";
config.telegram.urlSecret		= "rgthzju6hz5btv4nco4tiocr3ijxejiorc3iojcijoijo";
config.telegram.channel			= "yPush";

var request = require('request');



/* ============================================ TELEGRAM HELPERS ============================================ */
/* ============================================ TELEGRAM HELPERS ============================================ */
/* ============================================ TELEGRAM HELPERS ============================================ */

function telegramSend(id, user, type, payload) {
	return new Promise((resolve, reject) => {
		try {
			if(type == "text") {
				var options = {
				  uri: 'https://api.telegram.org/bot' + config.telegram.token + '/sendMessage',
				  method: 'POST',
				  json: {
					  "parse_mode": "Markdown",
					  "chat_id": "@" + config.telegram.channel,
					  "text": payload.text
				  }
				};
			}

			request(options, function (error, response, body) {
				if (!error && response.statusCode != 200) {
					console.error({error});
					console.error({response});

				} else {
					resolve(null);
				}
			});

		} catch(err) {
			console.error({err});
		}

	});
}


exports.telegramWebhook = (req, res) => {
	return telegramSend(null, null, "text", {text: req.body.text}); res.sendStatus(200); });
};
