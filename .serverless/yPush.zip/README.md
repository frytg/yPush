# yPush
## Simplifying developer alerts <3


## INSTALL

- Make sure you have the Serverless.com framework properly installed on your machine
- Text @BotFather to make a new Bot
- Create a new Channel on Telegram
- Go to your Channel -> Admins -> Add Admin and add your bot
- Copy the token you've received from BotFather and paste it to serverless.yml TELEGRAM_BOT_TOKEN
- Enable APIs and create credentials in GCP https://serverless.com/framework/docs/providers/google/guide/credentials#enable-the-necessary-apis, then save them as serverless-credentials.json
- 
- Run `sls deploy`
